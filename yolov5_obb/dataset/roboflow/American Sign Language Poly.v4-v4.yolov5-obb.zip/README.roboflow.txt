
American Sign Language Poly - v4 v4
==============================

This dataset was exported via roboflow.ai on April 15, 2022 at 3:26 PM GMT

It includes 1671 images.
Signs are annotated in YOLOv5 Oriented Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees
* Random brigthness adjustment of between -25 and +25 percent
* Random Gaussian blur of between 0 and 1.5 pixels
* Salt and pepper noise was applied to 1 percent of pixels


