# undefined > v4
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: undefined

This dataset includes all letters A through Z in American Sign Language labeled with polygon labels. See this blog post for how to train with Detectron2: https://blog.roboflow.com/p/4482cb2b-f378-48f6-bd58-df2b784670cf/